@extends('layouts.app')
@extends('layouts.content')
@extends('layouts.content-search')
@extends('layouts.sidebar')
