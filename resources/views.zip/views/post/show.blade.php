{{--@extends('layouts.app')--}}

@extends('layouts.post')

@extends('layouts.comment')
