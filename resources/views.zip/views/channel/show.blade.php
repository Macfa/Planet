  @extends('layouts.app')
  @extends('layouts.content')
  @extends('layouts.content-mainmenu')
  @extends('layouts.channelInfo')
