  @extends('mobile.layouts.app')
  @extends('mobile.layouts.content')
  @extends('mobile.layouts.content-mainmenu')
  @extends('mobile.layouts.channelInfo')
