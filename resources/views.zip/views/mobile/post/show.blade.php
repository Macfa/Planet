{{--@extends('layouts.app')--}}

@extends('mobile.layouts.post')

@extends('mobile.layouts.comment')
