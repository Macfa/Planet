@extends('mobile.layouts.post')
@extends('mobile.layouts.comment')
