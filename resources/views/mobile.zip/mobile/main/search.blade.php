@extends('mobile.layouts.app')
@extends('mobile.layouts.content')
@extends('mobile.layouts.content-search')
@extends('mobile.layouts.sidebar')
